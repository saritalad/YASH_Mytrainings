﻿using AsyncMultiThreadingDemo.SampleCodes;
using Microsoft.IdentityModel.Threading;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Security;

namespace AsyncMultiThreadingDemo
{
    internal class Program
    {
        static async void Main(string[] args)
        {
            Console.WriteLine("Code 1");
            Console.WriteLine("Code 2 " + Thread.CurrentThread.ManagedThreadId);
            var tk = Task.Run(() => SomeMethod());
            await tk;
            Console.WriteLine("Code 7");
            Console.WriteLine("Code 8");
            Console.Read();
        }
        private static async void SomeMethod()
        {
            Console.WriteLine("Code 3");
            Console.WriteLine("Code 4");
            await Task.Delay(10000); //Mimicing any I/O-bound activity
            Console.WriteLine("Code 5");
            Console.WriteLine("Code 6 " + Thread.CurrentThread.ManagedThreadId);
        }
    }
}
