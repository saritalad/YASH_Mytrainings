﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AsyncMultiThreadingDemo.SampleCodes
{
    internal class _5_1_Tasks_Factory
    {
        static void Main7()
        {
            //var task1 = Task.Factory.StartNew(() => DoWork(1, 5000), CancellationToken.None, TaskCreationOptions.None, TaskScheduler.Default);
            //var task2 = Task.Factory.StartNew(() => DoWork(2, 2000), CancellationToken.None, TaskCreationOptions.None, TaskScheduler.Default);
            //var task3 = Task.Factory.StartNew(() => DoWork(3, 3000), CancellationToken.None, TaskCreationOptions.None, TaskScheduler.Default);

            //var task1 = Task.Run(() => DoWork(1, 5000));
            //var task2 = Task.Run(() => DoWork(2, 2000));
            //var task3 = Task.Run(() => DoWork(3, 3000));

            var task4 = Task.Run(() =>
            {
                DoWork(1, 5000);
                var task5 = Task.Run(() =>
                {
                    DoWork(1, 2000);
                    var task6 = Task.Run(() => DoWork(3, 3000));
                    });
            });

            //Task.WaitAll(task1, task2, task3);
            task4.Wait();

            Console.WriteLine("Main thread exits");

            Console.ReadKey();
        }

        static void DoWork(int taskNumber, int waitDuration)
        {
            Task.Delay(waitDuration).Wait();
            Console.WriteLine(taskNumber);
        }
    }
}
