﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AsyncMultiThreadingDemo.SampleCodes
{
    internal class _0_1_Foreground_Threads
    {
        static void Main2()
        {
            Thread foregroundThread = new(new ThreadStart(LongTask));
            foregroundThread.Start();

            Console.WriteLine("Main thread is completing. Waiting for the foreground thread to finish.");
            foregroundThread.Join(); // Ensures the main thread waits for the foreground thread to finish
            Console.WriteLine("Foreground thread has completed, application will now close.");

            Console.ReadLine();
        }

        static void LongTask()
        {
            Console.WriteLine("Foreground thread starts.");
            Thread.Sleep(5000); // Simulates a long task
            Console.WriteLine("Foreground thread is still running, processing data...");
            Thread.Sleep(5000); // Continues to simulate a long task
            Console.WriteLine("Foreground thread has finished processing.");
        }
    }
}
