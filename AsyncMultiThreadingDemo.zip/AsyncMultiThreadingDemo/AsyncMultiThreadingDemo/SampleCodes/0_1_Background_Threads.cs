﻿namespace AsyncMultiThreadingDemo.SampleCodes
{
    internal class _0_1_Background_Threads
    {
        static void Main1()
        {
            Thread backgroundThread = new(new ThreadStart(BackgroundTask))
            {
                IsBackground = true  // Set the thread to background
            };
            backgroundThread.Start();

            //backgroundThread.Join();

            Console.WriteLine("Main thread is completing. Background thread may not finish.");
        }

        static void BackgroundTask()
        {
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Background thread running...");
                Thread.Sleep(1000);
            }
            Console.WriteLine("Background thread has completed, but this message may not display.");
        }
    }
}
