﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security;
using System.Text;
using System.Threading.Tasks;

namespace AsyncMultiThreadingDemo.SampleCodes
{
    internal class _5_3_TPL_PLINQ
    {
        static void Main11(string[] args)
        {
            //Creating a Collection of integer numbers
            var numbers = Enumerable.Range(1, 20);

            //Fetching the List of Even Numbers using LINQ
            //var evenNumbers = numbers.Where(x => x % 2 == 0).ToList();

            //Fetching the List of Even Numbers using PLINQ
            //PLINQ means we need to use AsParallel()
            var evenNumbers = numbers
                .AsParallel()
                .Where(x => x % 2 == 0)
                .Select(x => string.Format("Iteration: {0}, ThreadID: {1}, CoreID: {2}", x, Thread.CurrentThread.ManagedThreadId, GetCurrentProcessorNumber()))
                .ToList();

            Console.WriteLine("Even Numbers Between 1 and 20");
            foreach (var number in evenNumbers)
            {
                Console.WriteLine(number);
            }

            Console.ReadKey();
        }


        [DllImport("Kernel32.dll"), SuppressUnmanagedCodeSecurity]
        public static extern int GetCurrentProcessorNumber();
    }
}
