﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AsyncMultiThreadingDemo.SampleCodes
{
    internal class _2_ThreadPool_QueueUserWorkItem
    {
        static void Main4(string[] args)
        {
            // Create a CountdownEvent with an initial count of 2
            CountdownEvent countdown = new(2);

            // Queue two work items to the ThreadPool and pass the countdown as the state object
            ThreadPool.QueueUserWorkItem(WorkItem1, countdown);
            ThreadPool.QueueUserWorkItem(WorkItem2, countdown);

            // Wait for the countdown to reach zero
            countdown.Wait();

            Console.WriteLine("Main thread exits");

            Console.ReadKey();
        }

        // A work item that prints a message and signals the countdown
        static void WorkItem1(object state)
        {
            Console.WriteLine("WorkItem1");
            CountdownEvent countdown = (CountdownEvent)state;
            countdown.Signal();
        }

        // A work item that prints a message and signals the countdown
        static void WorkItem2(object state)
        {
            Console.WriteLine("WorkItem2");
            CountdownEvent countdown = (CountdownEvent)state;
            countdown.Signal();
        }
    }
}
