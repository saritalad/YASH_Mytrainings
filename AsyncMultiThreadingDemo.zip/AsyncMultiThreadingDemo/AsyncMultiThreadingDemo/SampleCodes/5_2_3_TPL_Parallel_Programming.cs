﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security;
using System.Text;
using System.Threading.Tasks;

namespace AsyncMultiThreadingDemo.SampleCodes
{
    internal class _5_2_3_TPL_Parallel_Programming
    {
        static void Main10(string[] args)
        {
            Console.WriteLine("C# Parallel For Loop");

            //It will start from 1 until 10
            //Here 1 is the start index which is Inclusive
            //Here 11 us the end index which is Exclusive
            //Here number is similar to i of our standard for loop
            //The value will be store in the variable number
            Parallel.For(1, 11, number => {
                Console.WriteLine("Iteration = {0}, Thread Id = {1}, CoreId = {2}"
                    , number
                    , Thread.CurrentThread.ManagedThreadId
                    , GetCurrentProcessorNumber());
            });
            Console.ReadLine();
        }


        [DllImport("Kernel32.dll"), SuppressUnmanagedCodeSecurity]
        public static extern int GetCurrentProcessorNumber();
    }
}
