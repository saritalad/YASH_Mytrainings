﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AsyncMultiThreadingDemo.SampleCodes
{
    public delegate int MyDelegate1(int x);
    public class MyClass1
    {
        //A method to be invoke by the delegate
        public int MyMethod(int x)
        {
            //simulate a long running proccess
            Thread.Sleep(10000);
            return x * x;
        }
    }

    internal class _4_2_Asynchronous_Delegate_WithoutAsyncCallback
    {
        static void Main6(string[] args)
        {
            MyClass1 myClass1 = new();
            MyDelegate1 del = new(myClass1.MyMethod);

            //Invoke our method in another thread
            IAsyncResult async = del.BeginInvoke(5, null, null);

            //loop until the method is complete
            while (!async.IsCompleted)
            {
                Console.WriteLine("Not Completed");
            }

            int result = del.EndInvoke(async);
            Console.WriteLine("Result is: {0}", result);
            Console.ReadLine();
        }
    }
}
