﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AsyncMultiThreadingDemo.SampleCodes
{
    internal class _5_4_1_TPL_Task_Based_Asynchronous_Pattern
    {
        static async void Main12(string[] args)
        {
            SomeMethod();
            Console.WriteLine("Main method code");
            Console.Read();
        }

        private static async void SomeMethod()
        {
            await Task.Delay(10000); //Mimicing any I/O-bound activity
            Console.WriteLine("Async code finished");
        }
    }
}