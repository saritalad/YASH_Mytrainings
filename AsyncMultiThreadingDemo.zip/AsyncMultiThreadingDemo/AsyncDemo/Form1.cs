using System.ComponentModel;

namespace AsyncDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Submit_Click(object sender, EventArgs e)
        {
            //start the operation on another thread  
            backgroundWorker2.RunWorkerAsync(2000);
        }

        private void btn_Cancel_Click(object sender, EventArgs e)
        {
            backgroundWorker2.CancelAsync();
        }

        //DoWork event handler is executed on a separate thread  
        private void backgroundWorker2_DoWork(object sender, DoWorkEventArgs e)
        {
            //a long running operation  
            for (int i = 1; i < 10; i++)
            {
                Thread.Sleep(1000);
                //backgroundWorker2.ReportProgress(i * 10);
                if (backgroundWorker2.CancellationPending)
                {
                    e.Cancel = true;
                    return;
                }
            }
        }

        private void backgroundWorker2_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                MessageBox.Show("Operation Cancelled");
            }
            else
            {
                MessageBox.Show("OperationCompleted");
            }
        }
    }
}
